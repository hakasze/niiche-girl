// script.js

function showPage(pageId){

  let pages = document.querySelectorAll(".page");

  pages.forEach(page=>{
    page.classList.remove("active");
  });

  document.getElementById(pageId).classList.add("active");
}

/* background bintang */

function createStar(){

  const star = document.createElement("div");

  star.classList.add("star");

  star.innerHTML = "✦";

  star.style.left = Math.random() * window.innerWidth + "px";

  star.style.fontSize = Math.random() * 15 + 10 + "px";

  star.style.animationDuration = Math.random() * 5 + 5 + "s";

  document.querySelector(".stars").appendChild(star);

  setTimeout(()=>{
    star.remove();
  },10000);
}

setInterval(createStar,200);